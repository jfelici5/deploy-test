import java.util.Scanner;

public class TheActualGame extends BoardController
{
    public TheActualGame(int N) {
        super(N);
    }

    public static void gameplay(){
        BoardController newGame = new BoardController(4);
        printGreeting();
        newGame.printBoard();
        Scanner reader = new Scanner(System.in);
        String input = reader.nextLine();
        while (input != null){
            boolean movePossible = false;
            System.out.println("The largest value is " + findMax(board));
            if(input.equalsIgnoreCase("a")){
                movePossible = newGame.moveLeft();
                if(movePossible){
                    steps++;
                }
                System.out.print("The key pressed was " + input);
                if(movePossible){
                    System.out.print("...and it made a valid move");
                    System.out.println("");
                }else{
                    System.out.print("...and it did not result in a valid move");
                    System.out.println("");
                }
                System.out.println("Total valid moves: " + steps);
                
            }else if(input.equalsIgnoreCase("d")){
                movePossible = newGame.moveRight();
                if(movePossible){
                    steps++;
                }
                System.out.print("The key pressed was " + input);
                if(movePossible){
                    System.out.print("...and it made a valid move");
                    System.out.println("");
                }else{
                    System.out.print("...and it did not result in a valid move");
                    System.out.println("");
                }
                System.out.println("Total valid moves: " + steps);
            }else if(input.equalsIgnoreCase("w")){
                movePossible = newGame.moveUp();
                if(movePossible){
                    steps++;
                }
                System.out.print("The key pressed was " + input);
                if(movePossible){
                    System.out.print("...and it made a valid move");
                    System.out.println("");
                }else{
                    System.out.print("...and it did not result in a valid move");
                    System.out.println("");
                }
                System.out.println("Total valid moves: " + steps);				
            }else if(input.equalsIgnoreCase("s")){
                movePossible = newGame.moveDown();
                if(movePossible){
                    steps++;
                }
                System.out.print("The key pressed was " + input);
                if(movePossible){
                    System.out.print("...and it made a valid move");
                    System.out.println("");
                }else{
                    System.out.print("...and it did not result in a valid move");
                    System.out.println("");
                }
                System.out.println("Total valid moves: " + steps);				
            }else if(input.equalsIgnoreCase("q")){
                System.out.println("Waiiiiiiiiiit..... are you sure you want to quit the game????");
                Scanner quit = new Scanner(System.in);
                System.out.println("To quit, enter 'q' again...if you made a mistake, hit 'n'");
                String quitInput = quit.nextLine();
                //verification
                if(quitInput.equalsIgnoreCase("q")){
                System.out.println("Okay...your wish is my command");
                break;
                }else if(quitInput.equalsIgnoreCase("n")){
                    System.out.println("welp...make another move!");
                    continue;
                }
            }else if(input.equalsIgnoreCase("r")){
                System.out.println("Waiiiiiiiiiit..... are you sure you want to start a new game????");
                Scanner reset = new Scanner(System.in);
                System.out.println("To quit, enter 'r' again...if you made a mistake, hit 'n'");
                String resetInput = reset.nextLine();
                //verification
                if(resetInput.equalsIgnoreCase("r")){
                System.out.println("Okay...your wish is my command");
                gameplay();
                }else if(resetInput.equalsIgnoreCase("n")){
                    System.out.println("welp...make another move!");
                    continue;
                }
            }else {
                System.out.println("Hmmmm..... it seems like our machines don't recognize that input");
                System.out.println("Something else, perhaps???");
                newGame.printBoard();
                input = reader.nextLine();
                continue;
            }
            System.out.println("*********************************************");
            if(movePossible){
                newGame.printNumber();
            }
            newGame.printBoard();
            if(newGame.fullBoard() && !newGame.slider()){
                System.out.println("Sorry. It appears you have lost. Try again???");
                break;
            }
            input = reader.nextLine();
        }
        newGame.printBoard();
    } 
            
    public static void main(String[] args){
        gameplay();
    }

}
