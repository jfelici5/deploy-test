Name: Juan Ramon Feliciano
NetID: jfelici5
Assignment: Project 1

This is my implementation of 2048! The BoardController class
contains the game logic. The TheActualGame class contains
the actual gameplay. Within the class containing the main method, 
I chose to wrap the gameplay within its own method that can be 
called whenever a user chooses to restart the game. 

Instructions are printed in the console when the game starts;
key pressed and valid moves/largest value are all displayed
after each turn.

The way that I made sure that '2' has a .8 chance of occurring and 
'4' has a .2 chance of occurring was by choosing a random number 
from a set of five numbers. I assigned four of the five numbers 
to indicate a 2, the remaining number indicates a 4. (4 out of 5
is 80%).

To run this program, navigate to the correct directory and compile

javac BoardController.java
javac TheActualGame.java

java TheActualGame