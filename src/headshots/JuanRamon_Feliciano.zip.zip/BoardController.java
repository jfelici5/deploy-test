import java.util.Random;

public class BoardController {
	
	public static int[][] board ;
	private int boardSize;
    public static int steps = 0;
	
	//setting up the initial board
	public void printBoard(){
		for(int i=0 ; i<boardSize; i++){
			for(int j=0; j<boardSize; j++){
				System.out.print(board[i][j]);
				if(j+1 < boardSize)
					System.out.print(" ][ ");
			}
			System.out.println();
        }
	}
	
	//declares a board of a certain size
	public BoardController(int X) {
		this.boardSize = X;
		board = new int[X][X];
		for(int i=0; i<X; i++){
			for(int j=0; j<X; j++){
				board[i][j] = 0;
			}
		}
		printNumber();
	}

	public static void printGreeting(){
		System.out.println("Welcome to my implementation of 2048!!!");
		System.out.println("Keyboard commands for movement:");
		System.out.println("W + ENTER for up");
		System.out.println("A + ENTER for left");
		System.out.println("S + ENTER for down");
		System.out.println("D + ENTER for right");
		System.out.println("Keyboard commands for quit and reset:");
		System.out.println("Q + ENTER for quit");
		System.out.println("R + ENTER for reset");
	}
	
	//method for adding new numbers
	public void printNumber(){
		if(!fullBoard()){
			Random r1 = new Random();
			Random r2 = new Random();
			int i = r1.nextInt(boardSize);	//used for coordinates of the new number in the array
			int j = r2.nextInt(boardSize);
			while(board[i][j] != 0){
				i = r1.nextInt(boardSize);
				j = r2.nextInt(boardSize);
			}
            int x = new Random().nextInt(5);
            //There are (5) available options for the random number: 
            //0, 1, 2, 3, 4
            //The assignment description asks to give 2 a .8 chance of happening
            //I allow 2 to be assigned the number if our random number is
            //0, 1, 2, or 3 AKA 4 out 5 possible outcomes AKA 0.8
			if( x == 0 || x ==1 || x==2 || x == 3) {
				board[i][j] = 2;
			}else {
                board[i][j] = 4;
			}
		}
	}
	
	public boolean moveLeft(){
		boolean movePossible = false;
		for(int i=0 ; i<boardSize; i++){
			int left = -1;
			for(int j=0; j<boardSize; j++){
				if ((left == -1 && board[i][j] != 0) || (left != -1 && board[i][j] != board[i][left])){
					left = j;
				}
				else if(left != -1 && board[i][j] == board[i][left]){
					if( board[i][j] != 0){
                        movePossible = true;
					}
					board[i][left] += board[i][j];
					board[i][j] = 0;
                    left = -1;
                }
			}
			left = 0;
			for(int j=0; j<boardSize; j++){
				if(board[i][j] != 0){
					if(left != j){
						if( board[i][j] != 0){
                            movePossible = true;
						}
						board[i][left] = board[i][j];
						board[i][j] = 0;
					}
                    left = left + 1;
				}
			}
		}
        return movePossible;
	}
	
	public boolean moveRight(){
		boolean movePossible = false;
		for(int i=0 ; i<boardSize; i++){
			int right = -1;
			for(int j=boardSize-1; j>=0; j--){
				if ((right == -1 && board[i][j] != 0)
						|| (right != -1 && board[i][j] != board[i][right])){
					right = j;
				}
				else if(right != -1 && board[i][j] == board[i][right]){
					if( board[i][j] != 0){
                        movePossible = true;
					}
					board[i][right] *= 2;
					board[i][j] = 0;
					right = -1;
				}
			}
			right = boardSize-1;
			for(int j=boardSize-1; j>=0; j--){
				if(board[i][j] != 0){
					if(right != j){
						board[i][right] = board[i][j];
						board[i][j] = 0;
                        movePossible = true;
					}
					right = right -1;
				}
			}
		}
		return movePossible;
	}
	
	public boolean moveUp() {
		boolean movePossible = false;
		for(int j=0 ; j<boardSize; j++){
			int up = -1;
			for(int i=0; i<boardSize; i++){
				if ((up == -1 && board[i][j] != 0)|| (up != -1 && board[i][j] != board[up][j])){
					up = i;
				}
				else if(up != -1 && board[i][j] == board[up][j]){
					if( board[i][j] != 0){
                        movePossible = true;
					}
					board[up][j] *= 2;
					board[i][j] = 0;
					up = -1;
				}
			}
			up = 0;
			for(int i=0; i<boardSize; i++){
				if(board[i][j] != 0){
					if(up != i){
						board[up][j] = board[i][j];
						board[i][j] = 0;
                        movePossible = true;
					}
					up = up + 1;
				}
			}
		}
		return movePossible;
	}

	public boolean moveDown() {
		boolean movePossible = false;
		for(int j=0 ; j<boardSize; j++){
			int down = -1;
			for(int i=boardSize-1; i>=0; i--){
				if ((down != -1 && board[i][j] != board[down][j]) || (down == -1 && board[i][j] != 0) ){
					down = i;
				}
				else if(down != -1 && board[i][j] == board[down][j]){
					if( board[i][j] != 0){
                        movePossible = true;
					}
					board[down][j] *= 2;
					board[i][j] = 0;
					down = -1;
				}
			}
			down = boardSize-1;
			for(int i=boardSize-1; i>=0; i--){
				if(board[i][j] != 0){
					if(down != i){
						board[down][j] = board[i][j];
						board[i][j] = 0;
                        movePossible = true;
					}
					down = down - 1;
				}
			}
		}
		return movePossible;
	}
	
	public boolean slider(){
		if(!fullBoard()){
			return true;
		}
		for(int i=0 ; i<boardSize; i++){
			for(int j=0; j<boardSize; j++){
				if( ( (i+1<boardSize) && (board[i][j] == board[i+1][j]) )
						|| ((j+1<boardSize) && (board[i][j] == board[i][j+1]) ))
					return true;
			}
		}
		return false;
	}
	
	public boolean fullBoard(){
		for(int i=0 ; i<boardSize; i++){
			for(int j=0; j<boardSize; j++){
				if(board[i][j] == 0)
					return false;
			}
		}
		return true;
    }

    static int findMax(int[][] board) 
    { 
		int max = Integer.MIN_VALUE; 
		 
		//loop updates max
        for (int i = 0; i < 4; i++) { 
            for (int j = 0; j < 4; j++) { 
                if (board[i][j] > max) { 
                    max = board[i][j]; 
                } 
            } 
        } 
          return max; 
    } 

}